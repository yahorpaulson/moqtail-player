import { log, clearLog, togglePause, exportLog } from "./logger.js";
import { BufReader } from "./BufReader.js";
import { synchronizeClock } from "./timeSynchronizer.js"

import {
  MOQ_VERSION,
  MSG_MAX_REQUEST_ID,
  MSG_SERVER_SETUP,
  MSG_SUBSCRIBE_OK,
  MSG_SUBSCRIBE_ERR,
  MSG_ANNOUNCE,
  MSG_GOAWAY,
  buildClientSetup,
  buildSubscribe,
  buildUnsubscribe,
  buildAnnounceOk,
} from "./moq.js";

import {
  initVideoBuffer,
  setMaxBufferSeconds,
  setLiveDelaySeconds,
  handlePayload,
  setActiveAlias,
  waitForFirstSegment,
  applyLiveDelayNow,
  getCurrentBufferSeconds,
} from "./videoBuffer.js";

import {
  startExperiment,
  stopExperiment,
  resetExperimentStats,
  exportExperimentCsv,
  setExperimentQuality,
  setUploadLimitMbps,
  getExperimentData,
  getRollingAverageLatency,
} from "./experiment-stats.js";


import {
  chooseQuality,
} from "./abr.js";

let transport = null;
let ctrlWriter = null;
let ctrlReader = null;
let mode = "subgroup";

let rateCounter = 0;
let reqIdCounter = 0;
let lastGroup = null;
let lastObject = null;

let stats = { received: 0, gaps: 0, errors: 0 };
let activeSubscription = null;

//ABR
let abrEnabled = true;
let lastAbrSwitchTime = 0;
const ABR_SWITCH_INTERVAL_MS = 5000;
let abrSwitchInProgress = false;
const CRITICAL_BUFFER_SECONDS = 0.2;

let initialSubscriptionReady = false;





let subscribeOkResolvers = new Map();
let subscribed = false;
let streamsListenerStarted = false;
let datagramListenerStarted = false;

let lastSeenByAlias = new Map();

window.addEventListener("DOMContentLoaded", async() => {
  try{
    const timeOffset = await synchronizeClock();

  } catch (error) {
      console.error(
        "Initial clock synchronization failed:",
        error,
      );
    }  

  initPlayer();
  initBufferControls();
  initMeasurementControls();
  initAbrControls();


  setInterval(() => {void forceDownswitch()}, 250);
});

function initAbrControls() {
  const checkbox = document.getElementById("abrEnabled");

  if (!checkbox) {
    return;
  }

  abrEnabled = checkbox.checked;

  checkbox.addEventListener("change", () => {
    abrEnabled = checkbox.checked;

    log(
      "info",
      abrEnabled
        ? "ABR enabled"
        : "ABR disabled: fixed quality",
    );
  });
}

function initPlayer() {
  const video = document.getElementById("videoPlayer");

  const mediaSource = new MediaSource();
  video.src = URL.createObjectURL(mediaSource);


  mediaSource.addEventListener("sourceopen", () => {
    const sourceBuffer = mediaSource.addSourceBuffer(
      'video/mp4; codecs="avc1.64001f"',
    );

    sourceBuffer.mode = "segments";

    initVideoBuffer({
      video,
      mediaSource,
      sourceBuffer,
    });
  });
}

function readUploadLimitFromUi() {
  const input =
    document.getElementById(
      "uploadLimitInput",
    );

  if (!input) {
    return "unlimited";
  }

  const rawValue =
    input.value.trim();

  if (!rawValue) {
    return "unlimited";
  }

  const numericValue =
    Number(rawValue);

  if (
    Number.isFinite(numericValue) &&
    numericValue > 0
  ) {
    return numericValue;
  }

  return rawValue;
}

function initMeasurementControls() {
  const startButton = document.getElementById("startMeasurementBtn");
  const stopButton = document.getElementById("stopMeasurementBtn");
  const resetButton = document.getElementById("resetMeasurementBtn");
  const exportButton = document.getElementById("exportMeasurementBtn");
  const printButton = document.getElementById("printMeasurementBtn");

  startButton?.addEventListener("click", () => {
    startMeasurement();
  });

  stopButton?.addEventListener("click", () => {
    stopMeasurement();
  });

  resetButton?.addEventListener("click", resetMeasurement);
  exportButton?.addEventListener("click", exportMeasurement);
  printButton?.addEventListener("click", printMeasurementSummary);
}

function initBufferControls() {
  const bufferInput = document.getElementById("bufferSizeInput");
  const delayInput = document.getElementById("delayInput");
  const bufferValue = document.getElementById("bufferSizeValue");

  if (bufferInput && bufferValue) {
    const applyBufferSize = () => {
      const value = Number(bufferInput.value);

      if (!Number.isFinite(value)) {
        return;
      }

      setMaxBufferSeconds(value);
      bufferValue.textContent = `${value} sec`;

    };

    applyBufferSize();
    bufferInput.addEventListener("input", applyBufferSize);
  }

  if (delayInput) {
    const applyDelay = () => {
      const value = Number(delayInput.value);

      if (!Number.isFinite(value)) {
        return;
      }

      setPlaybackDelay(value);
    };

    applyDelay();
    delayInput.addEventListener("input", applyDelay);
  }
}

(function () {
  const p = new URLSearchParams(location.search);
  if (p.get("url")) document.getElementById("serverUrl").value = p.get("url");

  document.getElementById("urlNote").textContent =
    location.origin + location.pathname;
})();

setInterval(() => {
  document.getElementById("statRate").textContent = rateCounter + "/s";
  rateCounter = 0;
}, 1000);

document.getElementById("modeDatagramBtn").onclick = () => setMode("datagram");
document.getElementById("modeStreamBtn").onclick = () => setMode("subgroup");
document.getElementById("connectBtn").onclick = () => doConnect();
document.getElementById("disconnectBtn").onclick = () => doDisconnect();

document.getElementById("subscribeBtn").onclick = async () => {
  const ns = document.getElementById("namespace").value.trim();
  const tn = document.getElementById("trackName").value.trim();

  if (!subscribed) {
    subscribed = true;
    document.getElementById("subscribeBtn").textContent = "Switch track";

    try {
      const result = await doSubscribe(ns, tn, true);

      if (!result) {
        subscribed = false;
        return;
      }

      renderTrackList();

      updateVideoOverlay(tn);
      setExperimentQuality(tn);
    } catch (e) {
      console.error("doSubscribe failed", e);
      subscribed = false;
    }

    return;
  }

  await switchTrack(ns, tn);
};

document.getElementById("clearLogBtn").onclick = () => clearLog();
document.getElementById("pauseBtn").onclick = () => togglePause();
document.getElementById("exportLogBtn").onclick = () => exportLog();

function pumpStream(readable, bufReader, label) {
  const reader = readable.getReader();

  (async () => {
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const bytes = new Uint8Array(value);

        bufReader.feed(bytes);
      }
    } catch (e) {
      log("debug", `Stream pump ended (${label}): ${e.message}`);
    }
  })();
}

async function doConnect() {
  const host = document.getElementById("serverUrl").value.trim();
  const port = document.getElementById("serverPort").value.trim() || "4433";
  const path = document.getElementById("serverPath").value.trim() || "/";

  if (!host) {
    log("error", "Enter server IP/hostname");
    return;
  }

  const url = `https://${host}:${port}${path}`;

  document.getElementById("serverLabel").textContent = url;
  setStatus("connecting", "Connecting…");

  log("info", `Connecting to ${url}`);
  try {
    transport = new WebTransport(url, {
      protocols: ["moqt-16"],
    });

    await transport.ready;

    setStatus("connected", "Connected");
    log("info", "WebTransport ready, opening control stream");

    document.getElementById("connectBtn").style.display = "none";
    document.getElementById("disconnectBtn").style.display = "";
    document.getElementById("subscribeBtn").disabled = false;

    const bidi = await transport.createBidirectionalStream();

    ctrlWriter = bidi.writable.getWriter();
    ctrlReader = new BufReader();

    pumpStream(bidi.readable, ctrlReader, "control");

    const setup = buildClientSetup();
    await ctrlWriter.write(setup);

    await readServerSetup();

    controlLoop();

    transport.closed
      .then(() => {
        log("info", "Connection closed by server");
        resetUi();
      })
      .catch((e) => {
        log("warn", `Connection closed: ${e.message}`);
        resetUi();
      });
  } catch (e) {
    setStatus("error", "Failed");
    log("error", `Connect failed: ${e.message}`);
    log(
      "warn",
      "Chrome tip: launch with --ignore-certificate-errors-spki-list=<fingerprint> or --ignore-certificate-errors",
    );
    transport = null;
  }
}

function updateThroughputOverlay(mbps) {
  const el = document.getElementById("throughputOverlay");
  if (!el) return;

  el.textContent = `${mbps.toFixed(2)} Mbps`;
}

function updateVideoOverlay(trackName) {
  const overlay = document.getElementById("videoTrackNameOverlay");
  if (!overlay) return;

  overlay.textContent = trackName;
}

function setPlaybackDelay(delaySeconds) {
  setLiveDelaySeconds(delaySeconds);

  applyLiveDelayNow();

  const delayOverlay = document.getElementById("delayOverlay");
  if (delayOverlay) {
    delayOverlay.textContent = `${delaySeconds} sec`;
  }
}

async function readKeyValuePair(r) {
  const key = await r.readVarint();

  if (key % 2 === 0) {
    const value = await r.readVarint();
    return { key, value };
  }

  const len = await r.readVarint();
  const value = await r.readBytes(len);
  return { key, value };
}

async function readServerSetup() {
  const msgType = await ctrlReader.readVarint();
  const msgLen = await ctrlReader.readU16();

  if (msgType !== MSG_SERVER_SETUP) {
    await ctrlReader.readBytes(msgLen);
    throw new Error(`Expected SERVER_SETUP, got 0x${msgType.toString(16)}`);
  }

  const payload = await ctrlReader.readBytes(msgLen);
  const r = new BufReader();

  r.feed(payload);

  const version = await r.readVarint();
  const numParams = await r.readVarint();

  for (let i = 0; i < numParams; i++) {
    await readKeyValuePair(r);
  }

  log("info", `SERVER_SETUP: selected version=0x${version.toString(16)}`);
}

async function controlLoop() {
  try {
    while (true) {
      const msgType = await ctrlReader.readVarint();
      const msgLen = await ctrlReader.readU16();

      switch (msgType) {
        case MSG_SUBSCRIBE_OK: {
          const payload = await ctrlReader.readBytes(msgLen);

          const r = new BufReader();
          r.feed(payload);

          const reqId = await r.readVarint();
          const trackAlias = await r.readVarint();

          log("info", `SUBSCRIBE_OK reqId=${reqId} alias=${trackAlias}`);

          const resolver = subscribeOkResolvers.get(reqId);
          if (resolver) {
            resolver(trackAlias);
            subscribeOkResolvers.delete(reqId);
          }

          if (activeSubscription && activeSubscription.reqId === reqId) {
            activeSubscription.alias = trackAlias;
            activeSubscription.live = true;
            renderTrackList();
          }

          break;
        }

        case MSG_SUBSCRIBE_ERR: {
          const payload = await ctrlReader.readBytes(msgLen);
          handleSubscribeError(payload);
          break;
        }

        case MSG_ANNOUNCE: {
          const numParts = await ctrlReader.readVarint();

          for (let i = 0; i < numParts; i++) {
            await ctrlReader.readString();
          }

          const numParams = await ctrlReader.readVarint();

          for (let i = 0; i < numParams; i++) {
            const k = await ctrlReader.readVarint();
            const vl = await ctrlReader.readVarint();
            await ctrlReader.readBytes(vl);
          }

          await ctrlWriter.write(buildAnnounceOk());
          break;
        }

        case MSG_MAX_REQUEST_ID: {
          const maxId = await ctrlReader.readVarint();
          break;
        }

        case MSG_GOAWAY: {
          const newSessionUri = await ctrlReader.readString();
          log("warn", `GOAWAY new_session_uri="${newSessionUri}"`);
          break;
        }

        default: {
          await ctrlReader.readBytes(msgLen);
        }
      }
    }
  } catch (e) {
    log("debug", `Control loop ended: ${e.message}`);
  }
}

function doDisconnect() {
  if (transport) {
    transport.close({ closeCode: 0, reason: "User disconnected" });
  }

  resetUi();
}

function resetUi() {
  document.getElementById("connectBtn").style.display = "";
  document.getElementById("disconnectBtn").style.display = "none";
  document.getElementById("subscribeBtn").disabled = true;

  setStatus("idle", "Disconnected");

  transport = null;
  ctrlWriter = null;
  ctrlReader = null;

  subscribed = false;
  streamsListenerStarted = false;
  datagramListenerStarted = false;
  activeSubscription = null;
  initialSubscriptionReady = false;
  abrSwitchInProgress = false;
  lastAbrSwitchTime = 0;
  subscribeOkResolvers.clear();

  renderTrackList();
}

async function handleSubscribeError(payload) {
  const r = new BufReader();
  r.feed(payload);

  const reqId = await r.readVarint();
  const code = await r.readVarint();

  const reasonLen = await r.readVarint();
  const reasonBytes = await r.readBytes(reasonLen);
  const reason = new TextDecoder().decode(reasonBytes);

  log(
    "error",
    `SUBSCRIBE_ERROR reqId=${reqId} code=${code} reason="${reason}"`,
  );

  const resolver = subscribeOkResolvers.get(reqId);
  if (resolver) {
    resolver(null);
    subscribeOkResolvers.delete(reqId);
  }
}

function waitForSubscribeOk(reqId) {
  return new Promise((resolve) => {
    subscribeOkResolvers.set(reqId, resolve);
  });
}

async function doSubscribe(ns, tn, makeActive = true) {
  if (!transport || !ctrlWriter) {
    log("error", "Not connected");
    return null;
  }

  if (!ns || !tn) {
    log("error", "Namespace and track name required");
    return null;
  }

  const reqId = reqIdCounter;

  reqIdCounter += 2;

  if (makeActive) {
    initialSubscriptionReady = false;

    activeSubscription = {
      reqId,
      ns,
      tn,
      alias: null,
      live: false,
      mode
    };
    renderTrackList();
  }

  const msg = buildSubscribe(reqId, ns, tn);

  log("info", `SUBSCRIBE reqId=${reqId} ns="${ns}" track="${tn}" mode=${mode}`);
  try {
    ctrlWriter.write(msg).catch((e) => {
      log("error", `Subscribe send failed: ${e.message}`);
    });
  } catch (e) {
    log("error", `Subscribe send failed sync: ${e.message}`);
    return null;
  }

  if (mode === "datagram") {
    if (!datagramListenerStarted) {
      datagramListenerStarted = true;
      listenDatagrams();
    }
  } else {
    if (!streamsListenerStarted) {
      streamsListenerStarted = true;
      listenStreams();
    }
  }

  const alias = await waitForSubscribeOk(reqId);

  if (alias === null) {
    log("error", "Subscribe failed");
    return null;
  }


  

  if (makeActive) {
    await waitForFirstSegment(alias);
    setActiveAlias(alias);

    activeSubscription = {
      reqId,
      alias,
      ns,
      tn,
      live: true,
      mode
    };

    initialSubscriptionReady = true;

    renderTrackList();

  }

  return { reqId, alias };
}

export async function doUnsubscribe(reqId) {
  if (reqId === undefined || reqId === null) {
    log("warn", "UNSUBSCRIBE skipped: reqId is missing");
    return;
  }

  if (!ctrlWriter) {
    log("warn", "UNSUBSCRIBE skipped: controlWriter is missing");
    return;
  }

  const bytes = buildUnsubscribe(reqId);

  log("info", `UNSUBSCRIBE reqId=${reqId}`);
  await ctrlWriter.write(bytes);
}

async function switchTrack(ns, tn) {
  const oldSubscription = activeSubscription ? { ...activeSubscription } : null;

  log("info", `switchTrack started ns="${ns}" track="${tn}"`);

  const result = await doSubscribe(ns, tn, false);
  if (!result) return;

  const { reqId, alias } = result;

  await waitForFirstSegment(alias);

  log("info", `Track switched to ${tn} alias=${alias}`);

  setActiveAlias(alias);
  updateVideoOverlay(tn);

  setExperimentQuality(tn);

  activeSubscription = {
    reqId,
    ns,
    tn,
    alias,
    live: true,
    mode
  };
    
  renderTrackList();


  if (oldSubscription && oldSubscription.reqId !== reqId) {
    await doUnsubscribe(oldSubscription.reqId);
  }
}

async function listenDatagrams() {
  log("info", "Listening for datagrams…");

  const dgReader = transport.datagrams.readable.getReader();

  try {
    while (true) {
      const { value, done } = await dgReader.read();
      if (done) break;

      try {
        const bytes = new Uint8Array(value);
        let off = 0;

        function rv() {
          const r = readVarintAt(bytes, off);
          off += r.len;
          return r.val;
        }

        const trackAlias = rv();
        const groupId = rv();
        const objectId = rv();
        const pubPriority = rv();
        const extLen = rv();

        off += extLen;

        const payload = bytes.slice(off);

        handlePayload(trackAlias, groupId, objectId, payload);
        processObject(trackAlias, groupId, objectId, payload.length);
      } catch (e) {
        stats.errors++;
        document.getElementById("statErrors").textContent = stats.errors;
        log("error", `Datagram parse error: ${e.message}`);
      }
    }
  } catch (e) {
    log("warn", `Datagram reader ended: ${e.message}`);
  }
}



function startMeasurement() {
  const quality =
    activeSubscription?.tn ??
    document.getElementById("trackName")?.value ??
    "unknown";

  const uploadLimitMbps = readUploadLimitFromUi();

  startExperiment({
    quality,
    uploadLimitMbps,
  });

  log(
    "info",
    `Measurement started quality=${quality} ` +
      `upload=${uploadLimitMbps ?? "unlimited"} Mbps`,
  );
}

function stopMeasurement() {
  const summary = stopExperiment();

  if (!summary) {
    return;
  }

  console.table(summary);

  log(
    "info",
    `RESULT quality=${summary.quality} ` +
      `upload=${summary.uploadLimitMbps}Mbps ` +
      `avgE2E=${summary.averageE2EMs}ms ` +
      `avgPlayer=${summary.averagePlayerLatencyMs}ms ` +
      `avgBuffer=${summary.averageBufferSeconds}s ` +
      `stalls=${summary.stallCount}`,
  );
}

function resetMeasurement() {
  resetExperimentStats();
}

function exportMeasurement() {
  exportExperimentCsv();
}

function printMeasurementSummary() {
  console.table(getExperimentData());
}

async function listenStreams() {
  log("info", "Listening for unidirectional streams…");

  const streamReader = transport.incomingUnidirectionalStreams.getReader();

  try {
    while (true) {
      const { value: stream, done } = await streamReader.read();

      if (done) break;


      handleSubgroupStream(stream).catch((e) => {
        log("error", `Subgroup stream failed: ${e.message}`);
      });
    }
  } catch (e) {
    log("warn", `Stream accept ended: ${e.message}`);
  }
}

async function handleSubgroupStream(stream) {

  const recvStart = performance.now();

  const sr = new BufReader();

  pumpStream(stream, sr, "subgroup");

  const streamType = await sr.readVarint();
  const trackAlias = await sr.readVarint();
  const groupId = await sr.readVarint();
  const subgroupId = await sr.readVarint();
  const publisherPriority = await sr.readByte();

  const objectIdDelta = await sr.readVarint();
  const extLen = await sr.readVarint();
  

  if (extLen > 0) {
    await sr.readBytes(extLen);
  }

  const payloadLen = await sr.readVarint();
  const payload = await sr.readBytes(payloadLen);
  const recvEnd = performance.now();
  const receiveTimeMs = recvEnd - recvStart;
  const throughputMbps = receiveTimeMs > 0? (payloadLen * 8) / (receiveTimeMs * 1000): 0;

  updateThroughputOverlay(throughputMbps);

  const publishTimestamp = readU64BE(payload.slice(0, 8));
  const videoPayload = payload.slice(8);

  handlePayload(
    trackAlias,
    groupId,
    objectIdDelta,
    videoPayload,
    publishTimestamp,
  );

  const isActiveTrack =
    trackAlias === activeSubscription?.alias;

  if (
    abrEnabled &&
    initialSubscriptionReady &&
    !abrSwitchInProgress &&
    isActiveTrack
  ) {
    const currentQuality = activeSubscription.tn;

    const bufferSeconds = getCurrentBufferSeconds();

    const selectedQuality = chooseQuality({
      throughputMbps,
      bufferSeconds,
      currentQuality,
    });

    if (
      selectedQuality &&
      selectedQuality !== currentQuality &&
      Date.now() - lastAbrSwitchTime >= ABR_SWITCH_INTERVAL_MS
    ) {
      log(
        "info",
        `ABR decision ${currentQuality} -> ${selectedQuality}`,
      );

      void performAbrSwitch(selectedQuality);
    }
  }

  processObject(trackAlias, groupId, objectIdDelta, payload.length);
}

async function performAbrSwitch(selectedQuality) {
  if (
    !abrEnabled ||
    !initialSubscriptionReady ||
    abrSwitchInProgress ||
    !activeSubscription ||
    selectedQuality === activeSubscription.tn
  ) {
    return;
  }

  const namespace = activeSubscription.ns;
  const oldQuality = activeSubscription.tn;

  abrSwitchInProgress = true;

  try {
    await switchTrack(namespace, selectedQuality);

    lastAbrSwitchTime = Date.now();

    log(
      "info",
      `ABR switch completed ${oldQuality} -> ${selectedQuality}`,
    );
  } catch (error) {
    log(
      "error",
      `ABR switch failed: ${error.message}`,
    );
  } finally {
    abrSwitchInProgress = false;
  }
}

async function forceDownswitch() {
  if (!abrEnabled || !initialSubscriptionReady) {
    return;
  }

  if (abrSwitchInProgress) {
    return;
  }

  const currentQuality =
    activeSubscription?.tn;

  if (
    !currentQuality ||
    currentQuality === "360p"
  ) {
    return;
  }

  const bufferSeconds =
    getCurrentBufferSeconds();

  if (bufferSeconds >= CRITICAL_BUFFER_SECONDS) {
    return;
  }

  log(
    "warn",
    `Emergency downswitch ${currentQuality} -> 360p ` +
      `buffer=${bufferSeconds.toFixed(2)}s`,
  );

  await performAbrSwitch("360p");
}


function readU64BE(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  return Number(view.getBigUint64(0, false));
}

function processObject(trackAlias, groupId, objectId, payloadLen) {
  rateCounter++;
  stats.received++;

  let gapFlag = false;

  const last = lastSeenByAlias.get(trackAlias);

  if (last) {
    if (
      groupId === last.groupId &&
      objectId !== last.objectId + 1 &&
      !(objectId === 0 && groupId > last.groupId)
    ) {
      gapFlag = true;
    } else if (groupId > last.groupId + 1) {
      gapFlag = true;
    }
  }

  if (gapFlag) {
    stats.gaps++;
    document.getElementById("statGaps").textContent = stats.gaps;
  }

  lastSeenByAlias.set(trackAlias, { groupId, objectId });

  lastGroup = groupId;
  lastObject = objectId;

  document.getElementById("statReceived").textContent = stats.received;
  document.getElementById("statGroup").textContent = groupId;
  document.getElementById("statObject").textContent = objectId;

  const shouldLog = gapFlag;

  if (shouldLog) {
    const tag = gapFlag
      ? '<span class="gap-tag">GAP</span>'
      : '<span class="ok-tag">OK</span>';

    log(
      "recv",
      `#${stats.received} alias=${trackAlias} g=${groupId} o=${objectId} ${payloadLen}B ${tag}`,
    );
  }
}

function readVarintAt(buf, off) {
  const first = buf[off];
  const lc = (first >> 6) & 0x3;

  if (lc === 0) return { val: first & 0x3f, len: 1 };

  const extra = [0, 1, 3, 7][lc];

  let val = first & 0x3f;

  for (let i = 1; i <= extra; i++) {
    val = val * 256 + buf[off + i];
  }

  return { val, len: 1 + extra };
}

function setMode(m) {
  mode = m;

  document
    .getElementById("modeDatagramBtn")
    .classList.toggle("active", m === "datagram");

  document
    .getElementById("modeStreamBtn")
    .classList.toggle("active", m === "subgroup");
}

function setStatus(type, text) {
  document.getElementById("statusBadge").className = "status-badge " + type;
  document.getElementById("statusText").textContent = text;
}

function renderTrackList() {
  const list = document.getElementById("tracksList");

  if (!activeSubscription) {
    list.innerHTML =
      '<div style="font-size:12px;color:var(--text3);padding:2px">No active subscription</div>';
    return;
  }

  list.innerHTML = `
    <div class="track-item active">
      <div class="track-icon">1</div>
      <div class="track-name">${activeSubscription.tn}</div>
      <div class="track-badge badge-live">
        ${activeSubscription.live ? "LIVE" : "…"}
      </div>
    </div>
  `;
}

function hexDump(bytes) {
  return (
    Array.from(bytes.slice(0, 32))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join(" ") + (bytes.length > 32 ? "…" : "")
  );
}

log("system", "MOQtail Player — MOQ draft-16 (version 0xff000010)");
log(
  "system",
  "Chrome: launch with --ignore-certificate-errors for self-signed QUIC certs",
);
log(
  "system",
  "Firefox: set network.webtransport.enabled=true and security.tls.enable_0rtt_data=false in about:config",
);
